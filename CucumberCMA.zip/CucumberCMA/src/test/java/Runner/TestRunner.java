package Runner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		features ="G:/CucumberCMA/src/test/java/features/MyApplication.feature",
		glue="stepDefination"
				)


public class TestRunner {
	
	
}
