package Utility;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class BrowserPage {
	
   public  WebDriver startApplication(WebDriver driver,String appURL)
	{

	
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
	     driver= new ChromeDriver();
   
	     
	driver.manage().window().maximize();
	driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	driver.get(appURL);
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  
	return driver;
	
   }
   
   
    public void quitBrowser(WebDriver driver) throws InterruptedException
   {
    	Thread.sleep(5000);
    	driver.quit();
    	
   }
	


    
}
