package stepDefination;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.LoginPage;
import Utility.BrowserPage;
import io.cucumber.java.en.*;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
public class SmokeTest
{
	WebDriver driver;
	
	@Given("Open chrome and start application")
	public void open_chrome_and_start_application()  {
		
		System.setProperty("webdriver.chrome.driver","driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://tide.com/en-us");
		
		
	}
	
	@And("^Navigate to url$")
	public void Navigate_to_url()  {
		
		BrowserPage bp =new BrowserPage();
      
		
	    
	}
	

	@When("^User perform testcases on website$")
	public void User_perform_testcases_on_website() throws InterruptedException {
		
		LoginPage lp =new LoginPage(driver);
		lp.loginToCRM();
		
	    
	}
	
     @Then("^closed the browser$")
	public void closed_the_browser() throws InterruptedException {
	Thread.sleep(3000);	
      driver.quit();
	    
	   
	}
}
