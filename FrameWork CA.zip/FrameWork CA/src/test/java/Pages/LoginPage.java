package Pages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import TestCases.LoginTestCRM;

public class LoginPage extends LoginTestCRM {
	
	//TestCase 1
	public WebElement pop;
	public WebElement item;
	public WebElement cl;
	
	//TestCase 2
	public WebElement foot;
	
	//TestCase 3
	public WebElement New;
	
	//TestCase 4
	public WebElement header;
	
	//TestCase 5
	public WebElement chat;
	
	//TestCase 6
	public WebElement pic;
	
	
	public LoginPage(WebDriver driver) throws InterruptedException
	{    
		
		 Thread.sleep(3000);
		 this.pop=driver.findElement(By.xpath("//a[@class='lilo3746-close-link lilo3746-close-icon']"));
		//TestCase 1
		 this.item=driver.findElement(By.name("q"));
		  this.cl=driver.findElement(By.xpath("//button[@type='submit']"));
	       String ActualTitle = driver.getTitle();
		  String ExpectedTitle = "Laundry Detergent and Fabric Care Products - Tide";
		  Assert.assertEquals(ExpectedTitle, ActualTitle);
		 
		
		  
		
		//TestCase 2
		   Thread.sleep(3000);
		   this.foot = driver.findElement(By.id("site-footer"));
		   List<WebElement> links=foot.findElements(By.tagName("a"));
		   int ar=links.size();
		   System.out.println("The no of links in the footer page is "+ar);
	
		//TestCase 3
		   Thread.sleep(3000);
		    this.New=driver.findElement(By.linkText("What’s New"));
	        String st= driver.getTitle();
	        System.out.println(st);
	        
		
		//TestCase 4
	        Thread.sleep(3000);
		    this.header = driver.findElement(By.id("site-header"));
			List<WebElement> links1=header.findElements(By.tagName("a"));
			int st1=links1.size();
			System.out.println("The no of links in the header page is "+st1);
		
		//TestCase 5
			 Thread.sleep(3000);
		  this.chat=driver.findElement(By.linkText("Live Chat"));
          String title= driver.getTitle();
           System.out.println(title);
	  
		//TestCase 6
           Thread.sleep(3000);
		  this. pic=driver.findElement(By.xpath("//img[starts-with(@alt,\"Brand Main Logo\")]"));
         if(pic.isDisplayed())
         {
        	System.out.println("Image is displayed");
        	System.out.println("The Image text is"+pic.getAttribute("alt"));
         } else
         {
        	System.out.println("Image is not dispalyed");
         }
           
           
	 }              
	          
	
	
	public void loginToCRM() throws InterruptedException {
		
		pop.click();
		
		//TestCase 1
		  item.sendKeys("tide purclean");
		  cl.click();

		
     	//TestCase 2
           foot.click();
	
     	//TestCase 3 
	      New.click();
		
	  //TestCase 4
	     header.click();
		
	   //TestCase 5
		 chat.click();
		
      //TestCase 6
		 pic.click();  
		 
	}
	
	}
