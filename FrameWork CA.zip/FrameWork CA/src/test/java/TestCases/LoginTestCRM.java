package TestCases;
import org.testng.annotations.Test;
import Pages.BaseClass;
import Pages.LoginPage;
import Utility.Exceldata;




public class LoginTestCRM extends BaseClass {
	 LoginPage loginPage;
	@Test
   public void loginApp() throws Exception
	{
		//Exceldata excel = new Exceldata();
		//excel.getStringData("Login", 0, 0);
		
		
		
		  loginPage=new LoginPage(driver);
		  
		 logger =report.createTest("Login to CRM");
		  
		  logger.info("Starting Application");
		  
		  logger.pass("login Success");
		 
		  
		loginPage.loginToCRM();
		
	}
	
	
}


