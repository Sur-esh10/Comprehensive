package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ConfigureDataProvider {
	
	Properties prop;
	
	public ConfigureDataProvider() 
	{
		
		File src= new File("./Config/ConfigData");
		try {
		FileInputStream fis = new FileInputStream(src);
		prop = new Properties();
		
			prop.load(fis);
		} catch (Exception e) {
			System.out.println("not able to load config file >>" +e.getMessage());
			
		}
}
	
	public String getDataFromConfig(String ToSearch)
	{
		return prop.getProperty(ToSearch);
	}
	
	
	
	public String getStagingURL()
	{
		return prop.getProperty("qaUrL");
	}

}
